SELECT
    ri.id,
    ri.ciSolicitante,
    solicitante.nombre AS nombreSolicitante,
    ri.ciTecnico,
    tecnico.nombre AS nombreTecnico,
    re.id AS idRegistroEspacio,
    e.id AS idEspacio,
    e.tipo AS tipoEspacio,
    e.numero AS numeroEspacio,
    g.nombre AS nombreGrupo,
    rti.id AS idTipoIncidencia,
    rti.tipo AS tipoIncidencia,
    rti.alumno,
    rti.descripcion AS descripcionIncidencia,
    ig.id AS idIncidenciaGeneral,
    ig.nombre AS nombreIncidenciaGeneral,
    eq.id AS idEquipo,
    eq.nombre AS nombreEquipo,
    es.id AS idEstado,
    es.tipo AS tipoEstado,
    es.prioridad,
    es.diagnostico,
    es.soluciones,
    ri.fecha
FROM
    REGISTROINCIDENCIA ri
    INNER JOIN USUARIO solicitante ON ri.ciSolicitante = solicitante.ci
    LEFT JOIN USUARIO tecnico ON ri.ciTecnico = tecnico.ci
    INNER JOIN REGISTROESPACIO re ON ri.idRegistroEspacio = re.id
    INNER JOIN ESPACIO e ON re.idEspacio = e.id
    INNER JOIN GRUPO g ON re.nombreGrupo = g.nombre
    INNER JOIN REGISTROTIPOINCIDENCIA rti ON ri.idTipoIncidencia = rti.id
    LEFT JOIN INCIDENCIAGENERAL ig ON rti.idIncidenciaGeneral = ig.id
    LEFT JOIN EQUIPO eq ON rti.idEquipo = eq.id
    INNER JOIN ESTADO es ON ri.idEstado = es.id;